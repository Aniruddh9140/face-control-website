"""
autostart.py - Make EyeSync wait for the website at every login.
=============================================================================

    python autostart.py install     start at every Windows login (and now, with --now)
    python autostart.py uninstall   stop starting at login
    python autostart.py status      is it installed / running?
    python autostart.py start       start EyeSync now (or show its window)
    python autostart.py stop        stop EyeSync now
    python autostart.py shortcuts   add "EyeSync" to the Desktop and Start menu
                                    (uninstall removes them again)

Installed, EyeSync waits invisibly at login (no window, no camera, no AI:
EyeSync.pyw --standby) and opens only when the EyeSync website dashboard
is opened; it closes again after the dashboard is closed. The window's
"Start with Windows" 
checkbox does the same as install/uninstall. Installation writes one
value under HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run
(current user only, no admin rights needed); uninstall removes it.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
VALUE_NAME = "EyeSync"


def pythonw() -> Path:
    """Windowless interpreter, preferring the project's virtual environment."""
    venv = HERE / ".venv" / "Scripts" / "pythonw.exe"
    if venv.exists():
        return venv
    candidate = Path(sys.executable).with_name("pythonw.exe")
    return candidate if candidate.exists() else Path(sys.executable)


def command(standby: bool = False) -> str:
    return (f'"{pythonw()}" "{HERE / "EyeSync.pyw"}"'
            + (" --standby" if standby else ""))


def enable() -> None:
    """At every Windows login, wait for the website dashboard (see the module docstring)."""
    import winreg
    with _key(True) as k:
        winreg.SetValueEx(k, VALUE_NAME, 0, winreg.REG_SZ, command(standby=True))


def disable() -> None:
    import winreg
    try:
        with _key(True) as k:
            winreg.DeleteValue(k, VALUE_NAME)
    except FileNotFoundError:
        pass


def _key(write: bool):
    import winreg
    access = winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE if write else winreg.KEY_QUERY_VALUE
    return winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, access)


def installed_command() -> str | None:
    import winreg
    try:
        with _key(False) as k:
            return winreg.QueryValueEx(k, VALUE_NAME)[0]
    except FileNotFoundError:
        return None


def running() -> bool:
    """True if the live tracker (background or manual) is running."""
    import ctypes
    SYNCHRONIZE = 0x00100000
    h = ctypes.windll.kernel32.OpenMutexW(SYNCHRONIZE, False, "Local\\EyeSync.LiveInference")
    if h:
        ctypes.windll.kernel32.CloseHandle(h)
        return True
    return False


def start(standby: bool = False) -> None:
    """Open EyeSync now - or, with ``standby``, only start waiting for the dashboard."""
    if running():
        import desktop
        desktop.bring_window_to_front("EyeSync", "TkTopLevel")
        print("EyeSync is already running - its window was brought to the front.")
        return
    subprocess.Popen(command(standby), cwd=str(HERE), creationflags=subprocess.DETACHED_PROCESS
                     | subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP)
    print("EyeSync is waiting - it opens when the EyeSync website dashboard is opened."
          if standby else "EyeSync started - its window opens in about 15 seconds.")


def stop() -> None:
    """End the background runner and the tracker (found by their command lines)."""
    ps = ("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "
          "'EyeSync.pyw|live_inference.py' -and $_.Name -match 'python' } | "
          "ForEach-Object { Stop-Process -Id $_.ProcessId -Force; $_.ProcessId }")
    out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                         capture_output=True, text=True).stdout.split()
    print(f"Stopped {len(out)} EyeSync process(es)." if out else "EyeSync was not running.")


SHORTCUT_NAME = "EyeSync.lnk"
ICON_PATH = HERE / "models" / "eyesync.ico"


def _shortcut_dirs() -> list[Path]:
    out = subprocess.run(["powershell", "-NoProfile", "-Command",
                          "[Environment]::GetFolderPath('Desktop'); "
                          "[Environment]::GetFolderPath('Programs')"],
                         capture_output=True, text=True).stdout.splitlines()
    return [Path(line.strip()) for line in out if line.strip()]


def make_icon() -> Path | None:
    """The window's eye icon as a Windows .ico (needs Pillow)."""
    try:
        import main_window
        img = main_window.icon_image()
        ICON_PATH.parent.mkdir(exist_ok=True)
        img.save(ICON_PATH, sizes=[(16, 16), (32, 32), (48, 48), (64, 64)])
        return ICON_PATH
    except Exception:                       # noqa: BLE001 - shortcut works without an icon
        return None


def add_shortcuts() -> None:
    """Desktop + Start menu shortcuts that start EyeSync in the background."""
    icon = make_icon()
    for folder in _shortcut_dirs():
        lnk = folder / SHORTCUT_NAME
        ps = ("$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:ES_LNK); "
              "$s.TargetPath = $env:ES_TARGET; $s.Arguments = $env:ES_ARGS; "
              "$s.WorkingDirectory = $env:ES_DIR; "
              "$s.Description = 'Control the mouse with your head and eyes'; "
              "if ($env:ES_ICON) { $s.IconLocation = $env:ES_ICON }; $s.Save()")
        env = {**__import__("os").environ, "ES_LNK": str(lnk), "ES_TARGET": str(pythonw()),
               "ES_ARGS": f'"{HERE / "EyeSync.pyw"}"', "ES_DIR": str(HERE),
               "ES_ICON": str(icon) if icon else ""}
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], env=env,
                           capture_output=True, text=True)
        print(f"Shortcut: {lnk}" if r.returncode == 0 else f"Could not create {lnk}: {r.stderr}")


def remove_shortcuts() -> None:
    for folder in _shortcut_dirs():
        lnk = folder / SHORTCUT_NAME
        if lnk.exists():
            lnk.unlink()
            print(f"Removed {lnk}")


def main() -> int:
    if sys.platform != "win32":
        print("autostart.py supports Windows only.")
        return 1
    p = argparse.ArgumentParser(description="EyeSync autostart at login")
    p.add_argument("action", choices=("install", "uninstall", "status", "start", "stop",
                                      "shortcuts"))
    p.add_argument("--now", action="store_true", help="with install: also start it right away")
    p.add_argument("--standby", action="store_true",
                   help="with start: don't open yet, wait for the website dashboard")
    a = p.parse_args()

    if a.action == "install":
        enable()
        print("Installed: at every login EyeSync waits for the website dashboard and opens "
              f"with it.\n  {command(True)}")
        if a.now:
            start(standby=True)
    elif a.action == "uninstall":
        disable()
        print("Uninstalled: EyeSync no longer starts at login.")
        remove_shortcuts()
    elif a.action == "status":
        cmd = installed_command()
        print(f"Autostart: {'INSTALLED' if cmd else 'not installed'}" + (f"\n  {cmd}" if cmd else ""))
        print(f"Running  : {'yes' if running() else 'no'}")
    elif a.action == "start":
        start(a.standby)
    elif a.action == "stop":
        stop()
    elif a.action == "shortcuts":
        add_shortcuts()
    return 0


if __name__ == "__main__":
    sys.exit(main())

# EyeSync

Control the mouse cursor with your head using an ordinary webcam, and click
by blinking or winking, or by holding the cursor still. No special hardware
and no hands needed. EyeSync waits quietly in the background and switches
on only while the EyeSync website dashboard is open.

- **Camera:** any webcam. Tracking runs at about 30 frames per second.
- **Mouse:** moves the Windows cursor directly, or uses a Seeed XIAO ESP32-S3
  plugged in as a USB mouse when one is connected.
- **Website:** [the EyeSync website](https://aniruddh9140.github.io/face-control-website/)
  receives live position and click data over WebSocket on
  `ws://localhost:8765` (also `ws://localhost:8080/eye-tracker`). On its
  Dashboard, press **Connect**.

## Install

1. Download the EyeSync zip from the EyeSync website.
2. Right-click it, choose **Extract All...**, then **Extract**.
3. In the extracted folder, double-click **`install.bat`**. If Windows
   says "Windows protected your PC", choose **More info**, then **Run
   anyway**. Wait a few minutes.

It:

- installs EyeSync in `%LocalAppData%\Programs\EyeSync`, so afterwards you
  can delete the zip and the extracted folder
- installs Python if the PC doesn't have it yet
- installs everything else EyeSync needs, and checks that it works
- adds an **EyeSync** shortcut to the Desktop and Start menu
- sets EyeSync to wait for the website, now and at every Windows login
- opens the EyeSync website: press **Connect** on its Dashboard, and EyeSync
  starts

The **EyeSync** shortcut opens its window any time. Needs Windows 10 or 11,
any webcam, and an internet connection during setup.

**Update:** download the new zip and run its `install.bat` the same way.
Your settings, calibration and API key stay.

**Remove:** double-click **`uninstall.bat`** in
`%LocalAppData%\Programs\EyeSync`. It stops EyeSync, removes the shortcuts
and the start at login, and asks before deleting the folder.

### Sharing EyeSync with other people

Run **`python make_release.py`**. It builds `dist/EyeSync-<version>.zip`
with only the program - none of your personal data (settings, calibration,
log or API key) - and runs the self-tests on the unpacked copy. It also
writes `dist/latest.json`, which the website uses to offer updates. Put both
on the website (see `WEBSITE.md`). Each person gets their own settings and
API key.

## Daily use

Everything is in the one EyeSync window:

- **Status** at the top, with a coloured dot:
  - grey: off, waiting for the EyeSync website
  - green: on, you control the cursor
  - red: on, but it can't see your face (check the lighting and that you're in view)
  - amber: paused
- **Camera view:** what EyeSync sees. Advice appears just above it, for
  example when the room is too dark.
- **Pause**, **Recenter** and **Calibrate** buttons
- **Settings:** speed, how to click, show camera, face gestures, start with
  Windows, and the **API key** for other websites and apps (see below)
- **Help**, **Open log** and **Quit EyeSync**

The window works with the EyeSync cursor too, so you never need the
keyboard. Closing the window (X) only minimises it. Use **Quit EyeSync** to
end it.

**EyeSync opens only with the website dashboard.** After Windows starts,
nothing opens: EyeSync waits invisibly (no window, no camera). When you
open the EyeSync website dashboard, EyeSync starts by itself (minimised in
the taskbar, ready in a few seconds). When you close the dashboard, EyeSync
closes again 30 seconds later and waits for the next time. The **EyeSync**
shortcut opens it at any time.

**After you quit EyeSync** (mouth wide open for 3 s, **Quit**, or F12), it
stays closed even though the dashboard keeps trying to reconnect: it starts
again only when you press **Connect** on the dashboard. The dashboard shows
why the connection ended ("EyeSync was closed - press Connect to start it
again").

1. **Open the EyeSync website.** EyeSync activates within a few seconds:
   the webcam light comes on and you control the cursor. When you close the
   website, cursor control stops after 4 seconds (so reloading the page or
   following a link inside the site never interrupts you) and the camera
   turns off a second later.
2. **Move the cursor with your head.** The cursor follows your nose the way
   it follows a mouse: turn your face a little to the right and the cursor
   goes right. Like a mouse, **slow movements are precise** (for small
   buttons) and **a normal turn goes far**: about 23 degrees crosses the
   whole screen at speed 1. The cursor glides smoothly, updating 120 times
   a second, even though the webcam sees you only 30 times a second.
   Holding your head still holds the cursor still,
   and nodding while you blink never moves it. If your head ends up turned
   uncomfortably, push the cursor against the screen edge and turn back, or
   press **Recenter**. It works without calibrating, but **Calibrate** (see
   below) fits it to you.
3. **Click**, in one of two ways (Settings → **Click by**):
   - **Blink** (the default): close both eyes for about ⅓ second, then open
     them. You hear a click sound every time a click registers. Ordinary
     quick blinks are ignored, and so is closing your eyes for more than
     1.5 seconds (resting). Works with glasses.
     **Right click:** close only your **right** eye for about ⅓ second (two
     short beeps). Closing only the left eye is a left click. Winks are
     ignored while your head is turned far to one side.
     **Moving your head never clicks.** Looking at the bottom of the screen
     makes your eyes look half closed to the camera. So EyeSync learns how
     your open eyes look in every head position, and it ignores any "blink"
     during which your head turned. Blink with your head still, after the
     cursor is on target.
   - **Hold still:** move the cursor onto something and keep it still for
     1 second. You hear a click sound. To click again, move away first, so
     resting on a page never clicks repeatedly. Choose this if deliberate
     blinking is hard for you.

### Calibrate: fit EyeSync to you (30 seconds)

EyeSync works without calibrating, but calibrating makes it fit *you*.
Press **Calibrate** in the window (or Ctrl+Alt+Shift+F10). The camera
turns on for it even if the website isn't open. A full-screen guide then
shows you what to do, and moves on by itself; you never need to click:

1. Look at the dot in the middle and keep still.
2. Turn your head to look at the dots on the left, right, top and bottom
   edges, holding still at each.
3. Blink slowly 3 times.
4. Give a big smile.

What it changes:

- **Speed:** the head movement you naturally make to look across the
  screen now moves the cursor across it at speed 1, separately for
  left-right and up-down. You no longer have to turn too far, and the cursor
  doesn't fly off. EyeSync switches to speed 1 afterwards; the higher speeds
  are still faster.
- **Blink clicks:** fitted to how far your eyes close (with or without
  glasses). EyeSync also learns how your open eyes look at each screen edge,
  so looking there is never taken as a blink.
- **Smile gesture:** set just below your big smile, so a light smile stays
  well under it.

It's saved and used every time from then on. Calibrate again whenever
something changes, for example new glasses, a new seat or a new camera.
Press **Cancel** or Esc to stop; your previous settings stay. A step you
don't finish within 20 seconds is skipped and keeps its default.

### Face gestures

Hold an expression for 1.5 seconds to change a setting. A sound confirms
it, and the camera view shows a progress bar while you hold.

| Gesture | Does |
|---|---|
| Blink both eyes, or wink the left eye (~⅓ s) | Left click |
| Wink the right eye (~⅓ s) | Right click (two short beeps) |
| **Big smile** (a wide, toothy one) | Pause / resume |
| **Mouth pulled clearly to one side** | Next speed (1 → 2 → … → 5 → 1) |
| **Mouth wide open, 3 s** | Quit EyeSync |

Talking, a light smile and opening your mouth for a moment don't trigger
anything. The quit countdown beeps only after the mouth has stayed wide
open for half a second. Gestures work with your head turned towards a
screen edge too. Turn gestures off in Settings if a long natural smile
still pauses EyeSync by mistake.

### Keys

Everything is also in the window. These optional shortcuts work
everywhere, even while EyeSync is minimised. Hold **Ctrl + Alt + Shift** and press:

| Key | Action |
|---|---|
| **F6** | Recenter: puts the cursor in the middle of the screen |
| **F7** / **F8** | Speed down (calmer) / up (faster). Five levels; your choice is saved. |
| **F9** | Pause or resume cursor control |
| **F10** | Calibrate (press again to cancel) |
| **F11** | Show the EyeSync window |
| **F12** | Quit EyeSync |

**Quit without the keyboard:** open your mouth wide and hold it for
3 seconds. A beep sounds when the countdown starts; close your mouth to
cancel.

### In a dark room

EyeSync keeps working in dim and dark rooms: when the camera picture gets
too dark and grainy to find your face, it cleans up and brightens the
picture by itself (the log says "Low light"). Your screen also lights your
face, so turning up the screen brightness helps a lot. In complete
darkness no ordinary webcam can see you; the window then says it's too
dark.

## API key: use EyeSync from other websites or apps

Out of the box, only the EyeSync website can connect to EyeSync. Any other
website or program has to show EyeSync's **API key**, so a random web page
you visit can't switch your cursor on or read where it is.

The key is made automatically the first time EyeSync starts, is different on
every PC, and stays the same until you replace it. In the window, under
Settings → **API key**:

- **Copy** puts the key on the clipboard. The window only shows its first
  and last few characters, so screen sharing doesn't reveal it.
- **New key** replaces it. Anything using the old key is disconnected at
  once and needs the new key. The EyeSync website is not affected.

To connect, add the key to the address. Anything connected with the key
switches EyeSync on, just like the website does:

```js
const key = "PASTE-YOUR-KEY-HERE";      // better: let the user paste it in, and keep
                                        // it in localStorage - never publish it
const ws = new WebSocket("ws://localhost:8080/eye-tracker?key=" + encodeURIComponent(key));
ws.onmessage = (e) => {
  const { x, y, blink, confidence, face } = JSON.parse(e.data);
  // x, y: cursor position in a 1920x1080 space; blink: true on a click
};
ws.onclose = (e) => {
  if (e.code === 4001) console.log("EyeSync refused:", e.reason);
  // "API key required", "invalid API key" or "API key changed"
};
```

Messages arrive about 30 times a second. Port 8765 works the same way.
Websites and apps can also send commands (enable/disable mouse control,
recenter, speed, click style): see **`WEBSITE.md`**.
Don't put the key in a public website's code: anyone could read it there.
Instead, have each user paste their own key into the page.

## Troubleshooting

| Problem | Fix |
|---|---|
| Your head is turned uncomfortably to reach things | Push the cursor against the screen edge, then turn back, or press **Recenter**. |
| Too much head movement needed, or too jumpy | Press **Calibrate** first. Then fine-tune with **Speed** in Settings: higher needs less head movement, lower is steadier. At speed 1 a head turn of about 23 degrees crosses the whole screen; speed 5 needs about 12. |
| Website shows "not connected" | Open the **EyeSync** shortcut, or close and reopen the dashboard. If it still doesn't connect, press **Open log** in the window and look for errors about ports 8080 or 8765. |
| Another site or app can't connect | It needs the API key (see above). The log shows `Refused a connection ... API key required` or `invalid API key`. |
| A click when you only moved your head | Should not happen any more: the log says `Head moved ... not a blink` each time it ignores one. If it still happens, send `eyesync.log`. |
| "It's too dark for the camera" | Turn on a light, or turn up your screen brightness (the screen lights your face). |
| "Can't open the camera" | Another app (Zoom, Teams, a browser tab) is using the webcam, or camera access is off in Windows Settings > Privacy > Camera. Fix that; EyeSync retries every 2 seconds and also tries a second or third camera. |

Everything EyeSync does is logged to **`eyesync.log`** in this folder. Every
5 minutes it also writes a `[health]` line with the frame rate, how often your
face was tracked, and any errors. If EyeSync ever closes by itself, the launcher
restarts it within seconds; `eyesync_crash.log` then says where it crashed.

## The XIAO ESP32-S3 as a hardware mouse (optional)

Flash `firmware/xiao_esp32s3_mouse/xiao_esp32s3_mouse.ino` with the Arduino
IDE. The board settings are at the top of that file; you need **USB Mode:
USB-OTG (TinyUSB)** and **USB CDC On Boot: Enabled**.

Plug the board in and EyeSync uses it automatically. Unplug it and EyeSync
goes back to moving the cursor itself. The board's BOOT button switches the
mouse output on and off.

## Your data

EyeSync stores no camera pictures. Nothing leaves this PC except the
cursor position and clicks it sends to the EyeSync website (and to apps
you give the API key). If you turn on the camera view on the website, the
small camera picture goes to that page in your browser too, only while it's
shown.

## Files

| File | Purpose |
|---|---|
| `live_inference.py` | The app: camera, face tracking, head pointer, blink and wink clicks, website link, hotkeys |
| `face_engine.py` | Camera access, low-light handling, MediaPipe face mesh |
| `desktop.py`, `software_mouse.py` | Windows hotkeys, sounds, background priority, cursor control |
| `site_access.py` | Who may connect (the website, the API key) and the standby that starts EyeSync when the website opens |
| `main_window.py` | The EyeSync window |
| `make_release.py` | Builds the zip to give to other people (no personal data) and `latest.json` for the website |
| `install.bat`, `uninstall.bat` | Install or update EyeSync; remove it |
| `autostart.py`, `EyeSync.pyw` | Start at login, shortcuts, restart after a crash. `python autostart.py uninstall` removes autostart and the shortcuts. |
| `WEBSITE.md` | How EyeSync and the website talk: connecting and starting EyeSync, data, commands, status, camera view, downloads |
| `WEBSITE_CHANGES.md` | The to-do list for the website (download page, controls) |
| `tests/` | Self-tests: `python -m unittest discover -s tests` |
| `eyesync_api_key.txt` | Your private API key. Don't share it; **New key** in the window replaces it. |

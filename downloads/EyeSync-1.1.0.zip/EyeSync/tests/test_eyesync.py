"""
EyeSync regression tests - no camera, website or hardware needed.

    python -m unittest discover -s tests -v        (from the EyeSync folder)

Covers the parts whose behaviour users feel directly: blink and wink clicks,
the head pointer, the close gesture, cursor motion (stops when the head
stops, lands on target), low light, the standby and the WebSocket output
the website consumes. Nothing here touches your real settings, API key or
log: the WebSocket tests use ports 8799, 8798 and 8796.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import tempfile
import threading
import time
import types
import unittest
from collections import deque
from pathlib import Path

import numpy as np

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
os.environ.setdefault("EYESYNC_LOG", os.path.join(tempfile.gettempdir(), "eyesync_test.log"))

import face_engine as fe           # noqa: E402
import live_inference as li        # noqa: E402

FPS = 30
li.desktop.play_warning_sound = li.desktop.play_click_sound = lambda: None   # silent tests
_log = logging.getLogger("eyesync")          # the app's expected warnings would look like
_log.addHandler(logging.NullHandler())       # test failures in the installer's output
_log.propagate = False


# --------------------------------------------------------------------------- #
# Blink -> click
# --------------------------------------------------------------------------- #

class BlinkTests(unittest.TestCase):
    O, C = 0.28, 0.07            # open / closed eye aspect ratio

    def buttons(self, seq, winks_ok=True) -> list[str]:
        """seq of (left eye EAR, right eye EAR) at 30 FPS -> the clicks, e.g. ["left", "right"]."""
        b = li.BlinkDetector(None, 0.55, 0.70, 0.25, 1.5, 0.6)
        b.baseline = self.O
        t, out = 0.0, []
        for left, right in seq:
            t += 1 / FPS
            click = b.update(left, right, t, None, winks_ok)[1]
            if click:
                out.append(click)
        return out

    def clicks(self, seq) -> int:
        return len(self.buttons(seq))

    def test_cases(self):
        O, C = self.O, self.C
        cases = {
            "involuntary blink 100 ms": ([(O, O)] * 20 + [(C, C)] * 3 + [(O, O)] * 20, 0),
            "deliberate blink 400 ms": ([(O, O)] * 20 + [(C, C)] * 12 + [(O, O)] * 20, 1),
            "deliberate blink with a 1-frame glitch":
                ([(O, O)] * 20 + [(C, C)] * 6 + [(O, O)] + [(C, C)] * 6 + [(O, O)] * 20, 1),
            "flicker at the threshold":
                ([(O, O)] * 20 + [(C, C)] * 5 + [(0.17, 0.17), (0.14, 0.14)] * 4 + [(O, O)] * 20, 1),
            "quick look down": ([(O, O)] * 20 + [(0.21, 0.21)] * 15 + [(O, O)] * 20, 0),
            "resting eyes 3 s": ([(O, O)] * 20 + [(C, C)] * 90 + [(O, O)] * 20, 0),
            "single-frame glitch": ([(O, O)] * 20 + [(C, C)] + [(O, O)] * 20, 0),
        }
        for name, (seq, expected) in cases.items():
            with self.subTest(name):
                self.assertEqual(self.clicks(seq), expected)

    def test_blink_seen_only_by_blink_score(self):
        """With glasses the eyelid points can miss a blink; the learned score still rises."""
        b = li.BlinkDetector(None, 0.55, 0.70, 0.2, 1.5, 0.6)
        b.baseline = self.O
        t, clicks = 0.0, 0
        # Developer's face: open-eye score ~0.02, a real blink only reached ~0.33.
        seq = [(0.02, 0.02)] * 30 + [(0.35, 0.33)] * 10 + [(0.02, 0.02)] * 20
        for sc in seq:
            t += 1 / FPS
            clicks += bool(b.update(self.O, self.O, t, sc)[1])   # eyelid geometry says open
        self.assertEqual(clicks, 1)

    def test_looking_down_is_not_a_blink(self):
        b = li.BlinkDetector(None, 0.55, 0.70, 0.2, 1.5, 0.6)
        b.baseline = self.O
        t, clicks = 0.0, 0
        seq = [(self.O, 0.03)] * 30 + [(0.22, 0.15)] * 20 + [(self.O, 0.03)] * 20
        for ear, sc in seq:
            t += 1 / FPS
            clicks += bool(b.update(ear, ear, t, (sc, sc))[1])
        self.assertEqual(clicks, 0)

    def test_winks(self):
        O, C = self.O, self.C
        pad = [(O, O)] * 20
        cases = {
            "both eyes 400 ms = left click": ([(C, C)] * 12, ["left"]),
            "left eye 400 ms = left click": ([(C, O)] * 12, ["left"]),
            "right eye 400 ms = right click": ([(O, C)] * 12, ["right"]),
            "right wink, other eye squinting a little": ([(0.21, C)] * 12, ["right"]),
            "involuntary one-eye twitch 100 ms": ([(O, C)] * 3, []),
            "wink that turns into a blink = left click": ([(O, C)] * 4 + [(C, C)] * 10, ["left"]),
            "one eye resting 3 s": ([(O, C)] * 90, []),
        }
        for name, (closure, expected) in cases.items():
            with self.subTest(name):
                self.assertEqual(self.buttons(pad + closure + pad), expected)
        # Head turned far to a side: the far eye looks closed - never a click.
        self.assertEqual(self.buttons(pad + [(O, C)] * 12 + pad, winks_ok=False), [])

    def test_cooldown(self):
        O, C = self.O, self.C
        blink = [(C, C)] * 12 + [(O, O)] * 3        # two blinks 0.5 s apart
        self.assertEqual(self.clicks([(O, O)] * 20 + blink * 2 + [(O, O)] * 20), 1)

    # -- head position (a real user: "due to the position of my face it registers a blink") --
    def run_posed(self, frames):
        """frames of (EAR, blink score, pitch) at 30 FPS -> (clicks, frames reported closed)."""
        b = li.BlinkDetector(None, 0.55, 0.70, 0.2, 1.5, 0.6)
        t, clicks, closed = 0.0, [], 0
        for ear, sc, pitch in frames:
            t += 1 / FPS
            shut, click = b.update(ear, ear, t, (sc, sc), True, (0.0, pitch))[:2]
            closed += shut
            if click:
                clicks.append(click)
        return clicks, closed

    @staticmethod
    def move(frm, to, frames):
        """Head turning from pitch frm to pitch to: (EAR, score, pitch). Looking further
        down lowers the eyelids (EAR 0.28 -> 0.15) and raises the blink score (to 0.55)."""
        out = []
        for i in range(1, frames + 1):
            p = frm + (to - frm) * i / frames
            k = min(max(-p / 20.0, 0.0), 1.0)          # 0 at the centre, 1 at -20 deg
            out.append((0.28 - 0.13 * k, 0.03 + 0.52 * k, p))
        return out

    def test_moving_the_head_down_and_back_is_not_a_blink(self):
        centre = [(0.28, 0.03, 0.0)] * 60
        at_bottom = self.move(-20, -20, 20)                 # 0.67 s looking at the screen bottom
        seq = centre + self.move(0, -20, 9) + at_bottom + self.move(-20, 0, 9) + centre
        self.assertEqual(self.run_posed(seq)[0], [])

    def test_blinks_work_while_looking_at_the_screen_bottom(self):
        centre = [(0.28, 0.03, 0.0)] * 60
        bottom = self.move(-20, -20, 1)[0]
        blink = [(0.05, 0.95, -20.0)] * 12                  # a real 0.4 s blink down there
        seq = centre + self.move(0, -20, 9) + [bottom] * 60 + blink + [bottom] * 30
        clicks, closed = self.run_posed(seq)
        self.assertEqual(clicks, ["left"])
        # The cursor is held only during the real blink, not while looking down.
        self.assertLess(closed, 12 + 10)

    def test_blink_with_a_small_nod_still_clicks(self):
        centre = [(0.28, 0.03, 0.0)] * 60
        nod = [(0.05, 0.95, -3.0 * i / 6) for i in range(1, 7)] + [(0.05, 0.95, -3.0)] * 6
        clicks, _ = self.run_posed(centre + nod + centre)
        self.assertEqual(clicks, ["left"])

    def test_blink_after_resting_eyes_is_not_a_click(self):
        O, C = self.O, self.C
        rest = [(C, C)] * 75 + [(O, O)] * 9            # eyes closed 2.5 s, open 0.3 s...
        blink = [(C, C)] * 10 + [(O, O)] * 30          # ...then the natural blink
        self.assertEqual(self.clicks([(O, O)] * 20 + rest + blink), 0)
        later = [(O, O)] * 45 + blink                   # a deliberate blink 1.5 s later still clicks
        self.assertEqual(self.clicks([(O, O)] * 20 + rest + later), 1)
        long_blink = [(C, C)] * 20 + [(O, O)] * 30      # 0.67 s right away: deliberate, clicks
        self.assertEqual(self.clicks([(O, O)] * 20 + rest + long_blink), 1)


# --------------------------------------------------------------------------- #
# Head pointer
# --------------------------------------------------------------------------- #

class HeadPointerTests(unittest.TestCase):
    FACE = 95.0                      # eye-corner distance in pixels (~40 cm from the camera)

    def pointer(self):
        hp = li.HeadPointer(1920, 1080)
        hp.reset()
        return hp

    def test_starts_where_asked(self):
        hp = li.HeadPointer(1920, 1080)
        hp.reset(np.array([300.0, 200.0]))
        np.testing.assert_allclose(hp.target(np.array([320.0, 240.0]), self.FACE, 2), [300, 200])

    def test_directions(self):
        hp = self.pointer()
        base = np.array([320.0, 240.0])
        hp.target(base, self.FACE, 2)
        right = hp.target(base + [-10, 0], self.FACE, 2)       # user turns right: nose moves image-left
        self.assertGreater(right[0], 960 + 50)
        down = hp.target(base + [0, 8], self.FACE, 2)           # user tilts down
        self.assertGreater(down[1], 540 + 50)

    def test_edges_never_get_stuck(self):
        hp = self.pointer()
        base = np.array([320.0, 240.0])
        hp.target(base, self.FACE, 2)
        self.assertEqual(hp.target(base + [-200, 0], self.FACE, 2)[0], 1919)  # far past the right edge
        back = hp.target(base + [-190, 0], self.FACE, 2)        # turn back a little
        self.assertLess(back[0], 1919 - 50, "cursor stuck at the edge")

    def test_slow_is_precise_quick_goes_far(self):
        """The same 0.3-face-width turn: slowly (2 s) moves the cursor a little, quickly far."""
        turn = 0.3 * self.FACE

        def moved(seconds):
            hp = self.pointer()
            n = int(seconds * FPS)
            for i in range(n + 1):
                pos = hp.target(np.array([320.0 - turn * i / n, 240.0]), self.FACE, 1, i / FPS)
            return pos[0] - 960
        slow = moved(2.0)
        quick = moved(0.1)                     # 3 face widths/s: a typical quick turn (measured)
        self.assertLess(slow, 0.3 * 1920 / li.HEAD_RANGE[1][0] + 5)
        self.assertGreater(quick, 2.5 * slow)

    def test_blink_nod_does_not_move_the_cursor(self):
        hp = self.pointer()
        hp.target(np.array([320.0, 240.0]), self.FACE, 2, 0.0)
        hp.target(np.array([320.0, 240.0]), self.FACE, 2, 1 / FPS)
        # eyes closed for 0.4 s (no frames used) while the head nods down 6 px
        after = hp.target(np.array([320.0, 246.0]), self.FACE, 2, 0.45)
        np.testing.assert_allclose(after, [960, 540])
        self.assertGreater(hp.target(np.array([320.0, 252.0]), self.FACE, 2, 0.45 + 1 / FPS)[1], 545)

    def test_distance_does_not_change_speed(self):
        near, far = self.pointer(), self.pointer()
        near.target(np.array([320.0, 240.0]), self.FACE * 1.5, 2)
        far.target(np.array([320.0, 240.0]), self.FACE, 2)
        a = near.target(np.array([320.0 - 15, 240.0]), self.FACE * 1.5, 2)   # same head turn,
        b = far.target(np.array([320.0 - 10, 240.0]), self.FACE, 2)         # closer = bigger in image
        self.assertAlmostEqual(a[0], b[0], delta=1)

    def test_steady_and_precise_with_real_jitter(self):
        """Nose jitter measured on the developer's recordings: ~0.45 px. Rest, small move, rest."""
        rng = np.random.default_rng(5)
        for level in li.SENSITIVITY_LEVELS:
            with self.subTest(level=level):
                hp = self.pointer()
                mc, beta, start, stop, vmax = li.SENSITIVITY_LEVELS[level]
                f, m = li.OneEuroFilter(mc, beta), li.CursorMotion(start, stop, vmax)
                hist, pos = deque(maxlen=li.NOSE_MEDIAN_FRAMES), []
                for i in range(240):
                    t = i / FPS
                    u = min(max(t - 3.0, 0.0), 1.0)
                    nose = np.array([320.0 - 12 * (3 * u * u - 2 * u * u * u), 240.0])
                    hist.append(nose + rng.normal(0, 0.45, 2))
                    tgt = hp.target(np.median(np.array(hist), axis=0), self.FACE, level)
                    pos.append(m(f(tgt, t), t).copy())
                pos = np.array(pos)
                # Judge the distance moved: the first (noisy) frame sets the
                # reference, which shifts every position by the same few px.
                expected = 12 / self.FACE * 1920 / li.HEAD_RANGE[level][0]   # a slow move
                self.assertLess(np.ptp(pos[30:89], axis=0).max(), 3, "cursor wobbles at rest")
                self.assertLess(np.ptp(pos[-40:], axis=0).max(), 3, "cursor wobbles after moving")
                # It may stop short by less than the dead zone: the slow end
                # of a movement is ignored like any small movement.
                self.assertLess(abs(pos[-1][0] - pos[88][0] - expected), start,
                                "cursor did not follow the head")

    def test_noisier_webcam_rarely_nudges_at_rest(self):
        """A webcam twice as noisy (1 px): the dead zone grows with the measured noise."""
        for level in (1, 3, 5):
            moved = 0
            for seed in range(30):
                rng = np.random.default_rng(seed)
                hp = self.pointer()
                mc, beta, start, stop, vmax = li.SENSITIVITY_LEVELS[level]
                f, m = li.OneEuroFilter(mc, beta), li.CursorMotion(start, stop, vmax)
                hist, pos = deque(maxlen=li.NOSE_MEDIAN_FRAMES), []
                for i in range(90):
                    t = i / FPS
                    hist.append(np.array([320.0, 240.0]) + rng.normal(0, 1.0, 2))
                    tgt = hp.target(np.median(np.array(hist), axis=0), self.FACE, level)
                    pos.append(m(f(tgt, t), t).copy())
                moved += np.ptp(np.array(pos)[30:89], axis=0).max() >= 3
            self.assertLessEqual(moved, 4, f"level {level}: nudged in {moved}/30 rests")


# --------------------------------------------------------------------------- #
# Face gestures
# --------------------------------------------------------------------------- #

class FaceGestureTests(unittest.TestCase):
    # Resting levels measured on the developer's face (with glasses).
    REST = {"mouthSmileLeft": 0.001, "mouthSmileRight": 0.001, "mouthPucker": 0.17,
            "mouthLeft": 0.003, "mouthRight": 0.003}

    def run_seq(self, segments):
        """segments: (seconds, {score overrides}) -> list of fired gestures."""
        g, t, fired = li.FaceGestures(), 0.0, []
        for secs, over in segments:
            for _ in range(int(round(secs * FPS))):
                t += 1 / FPS
                f = g.update({**self.REST, **over}, t)
                if f:
                    fired.append(f)
        return fired

    def test_each_gesture_fires_once(self):
        smile = {"mouthSmileLeft": 0.8, "mouthSmileRight": 0.75}
        self.assertEqual(self.run_seq([(3, {}), (1.7, smile), (1, {})]), ["smile"])
        self.assertEqual(self.run_seq([(3, {}), (1.7, {"mouthPucker": 0.8}), (1, {})]), [])  # removed
        self.assertEqual(self.run_seq([(3, {}), (1.7, {"mouthRight": 0.6}), (1, {})]), ["side"])

    def test_holding_on_fires_only_once(self):
        smile = {"mouthSmileLeft": 0.8, "mouthSmileRight": 0.8}
        self.assertEqual(self.run_seq([(3, {}), (5, smile)]), ["smile"])
        self.assertEqual(self.run_seq([(3, {}), (1.7, smile), (0.5, {}), (1.7, smile)]),
                         ["smile", "smile"])

    def test_short_expressions_do_nothing(self):
        smile = {"mouthSmileLeft": 0.8, "mouthSmileRight": 0.8}
        self.assertEqual(self.run_seq([(3, {}), (1.0, smile), (1, {}), (0.8, {"mouthPucker": 0.8})]), [])

    def test_talking_does_nothing(self):
        rng = np.random.default_rng(2)
        segs = [(3, {})] + [(0.2, {"mouthPucker": float(rng.uniform(0.1, 0.66)),
                                   "mouthSmileLeft": float(rng.uniform(0, 0.3)),
                                   "mouthLeft": float(rng.uniform(0, 0.2))}) for _ in range(60)]
        self.assertEqual(self.run_seq(segs), [])

    def test_brief_sag_does_not_cancel(self):
        smile = {"mouthSmileLeft": 0.8, "mouthSmileRight": 0.8}
        self.assertEqual(self.run_seq([(3, {}), (0.8, smile), (0.2, {}), (0.9, smile)]), ["smile"])

    def test_light_smile_does_nothing(self):
        light = {"mouthSmileLeft": 0.5, "mouthSmileRight": 0.45, "mouthRight": 0.3}
        self.assertEqual(self.run_seq([(3, {}), (4, light), (1, {})]), [])

    def test_big_smile_works_with_the_head_turned(self):
        """At a screen edge the far half of the mouth is scored low."""
        g, t, fired = li.FaceGestures(), 0.0, []
        smile = {**self.REST, "mouthSmileLeft": 0.85, "mouthSmileRight": 0.3}
        for secs, bs in ((3, self.REST), (1.7, smile), (1, self.REST)):
            for _ in range(int(secs * FPS)):
                t += 1 / FPS
                if f := g.update(bs, t, (24.0, -5.0)):
                    fired.append(f)
        self.assertEqual(fired, ["smile"])
        # Facing the camera, a lopsided half-smile like that is not a big smile.
        self.assertEqual(self.run_seq([(3, {}), (1.7, {"mouthSmileLeft": 0.85,
                                                          "mouthSmileRight": 0.3})]), [])

    def test_resting_levels_are_learned_per_head_direction(self):
        """Turned to a side, this face's resting side-mouth score is 0.25."""
        g, t, fired = li.FaceGestures(), 0.0, []
        side_rest = {**self.REST, "mouthRight": 0.25}
        for secs, bs, pose in ((3, self.REST, (0.0, 0.0)), (3, side_rest, (24.0, 0.0)),
                               (1.7, {**self.REST, "mouthRight": 0.5}, (24.0, 0.0)),
                               (1.0, self.REST, (0.0, 0.0)),
                               (1.7, {**self.REST, "mouthRight": 0.5}, (0.0, 0.0))):
            for _ in range(int(secs * FPS)):
                t += 1 / FPS
                if f := g.update(bs, t, pose):
                    fired.append((f, pose[0]))
        # 0.5 is only 0.25 above this face's level when turned (not a pull), a clear one ahead.
        self.assertEqual(fired, [("side", 0.0)])


# --------------------------------------------------------------------------- #
# Dwell -> click
# --------------------------------------------------------------------------- #

class DwellTests(unittest.TestCase):
    """Paths are (seconds, x, moving) segments; the cursor starts resting at x=100."""

    def setUp(self):
        self.t = 0.0
        self.d = li.DwellClicker(1.0, 60.0)

    def run_path(self, segments, start=True) -> int:
        if start:
            segments = [(0.3, 100, False)] + segments
        clicks = 0
        for secs, x, moving in segments:
            for _ in range(int(round(secs * FPS))):
                self.t += 1 / FPS
                clicks += self.d.update(np.array([x, 500.0]), moving, self.t)
        return clicks

    def test_move_then_rest_clicks_once(self):
        self.assertEqual(self.run_path([(0.3, 300, True), (4.0, 300, False)]), 1)

    def test_never_moved_never_clicks(self):
        self.assertEqual(self.run_path([(5.0, 100, False)]), 0)

    def test_small_moves_do_not_rearm(self):
        self.assertEqual(self.run_path([(0.3, 300, True), (1.2, 300, False),
                                        (0.2, 330, True), (2.0, 330, False)]), 1)

    def test_moving_away_rearms(self):
        self.assertEqual(self.run_path([(0.3, 300, True), (1.2, 300, False),
                                        (0.3, 450, True), (1.2, 450, False)]), 2)

    def test_short_rest_does_not_click(self):
        self.assertEqual(self.run_path([(0.3, 300, True), (0.8, 300, False), (0.3, 500, True)]), 0)

    def test_blink_restarts_timer(self):
        self.assertEqual(self.run_path([(0.3, 300, True), (0.7, 300, False)]), 0)
        self.d.pause()                                     # a blink froze the cursor
        self.assertEqual(self.run_path([(0.7, 300, False)], start=False), 0)
        self.assertEqual(self.run_path([(0.4, 300, False)], start=False), 1)


# --------------------------------------------------------------------------- #
# The EyeSync window
# --------------------------------------------------------------------------- #

class WindowTests(unittest.TestCase):
    def test_status_keys(self):
        import main_window
        screen = fe.ScreenSize(1920, 1080)
        args = types.SimpleNamespace(always_active=False)
        st = li.SharedState(screen, 2, False)
        self.assertEqual(li.status_of(st.read(), args)[0], "off")
        st.update(site_clients=1)
        self.assertEqual(li.status_of(st.read(), args)[0], "off")         # camera starting
        st.update(has_position=True, face=True)
        self.assertEqual(li.status_of(st.read(), args)[0], "active")
        st.update(face=False)
        self.assertEqual(li.status_of(st.read(), args)[0], "noface")
        st.update(paused=True)
        self.assertEqual(li.status_of(st.read(), args)[0], "paused")
        for key in ("off", "active", "noface", "paused"):
            self.assertIn(key, main_window.COLORS)

    def test_controls_drive_the_engine(self):
        import tkinter as tk

        import main_window
        try:
            root = tk.Tk()
        except tk.TclError as exc:
            self.skipTest(f"no display: {exc}")
        saved = li.save_settings
        li.save_settings = lambda **kw: None              # don't touch the real settings file
        tmp = tempfile.TemporaryDirectory()
        try:
            root.withdraw()
            win = main_window.MainWindow(root, False, PROJECT / "README.md", PROJECT)
            st = li.SharedState(fe.ScreenSize(1920, 1080), 2, False)
            args = types.SimpleNamespace(always_active=False)
            api_key = li.ApiKey(Path(tmp.name) / "key.txt")
            win.attach(st, li.Actions(st, api_key), lambda: li.status_of(st.read(), args))

            key = api_key.get()
            self.assertNotIn(key, win.key_var.get())       # shown masked
            self.assertTrue(win.key_var.get().endswith(key[-4:]))
            copied = []
            root.clipboard_clear = lambda: None           # leave the user's clipboard alone
            root.clipboard_append = copied.append
            win.copy_key_btn.invoke()
            self.assertEqual(copied, [key])

            win.pause_btn.invoke()
            self.assertTrue(st.read().paused)
            win.refresh()
            self.assertEqual(win.pause_btn.cget("text"), "Resume")
            win.recenter_btn.invoke()
            self.assertTrue(st.recenter_request.is_set())
            win.sens_var.set(5)
            win._set_sensitivity()
            self.assertEqual(st.read().sensitivity, 5)
            win.click_var.set("dwell")
            win._set_click()
            self.assertEqual(st.read().click_mode, "dwell")

            st.update(hint="look at the centre")
            st.set_preview(np.zeros((main_window.PREVIEW_H, main_window.PREVIEW_W, 3), np.uint8))
            win.refresh()
            self.assertEqual(win.hint_var.get(), "look at the centre")
            self.assertIsNotNone(win._photo)               # camera image shown
            self.assertEqual(win.status_var.get(), li.status_of(st.read(), args)[1])

            # Calibrate: the guide opens (hidden here, not over the real screen),
            # follows the steps, and Cancel closes it.
            ov = win.overlay

            def hidden_show():
                ov.top = tk.Toplevel(root)
                ov.top.withdraw()
                ov.canvas = tk.Canvas(ov.top)
                ov.drawn = None
            ov._show = hidden_show
            self.assertIn("Not calibrated", win.calib_var.get())
            win.calibrate_btn.invoke()
            self.assertTrue(st.calibrate_request.is_set())
            win.refresh()
            self.assertIsNotNone(ov.top)
            st.update(calib_step="left", calib_text="Turn your head...", calib_progress=0.5)
            win.refresh()
            self.assertEqual(ov.drawn, ("left", "Turn your head...", 0.5))
            win.calibrate_btn.invoke()                     # pressed again: cancel
            self.assertTrue(st.calibrate_cancel.is_set())
            win.refresh()
            self.assertIsNone(ov.top)
            st.update(calib_step="done", calib_text="Calibration done!", calibrated="2026-10-15")
            win.refresh()
            self.assertIn("2026-10-15", win.calib_var.get())
            ov.done_since = time.monotonic() - ov.RESULT_S - 1   # the result was shown long enough
            win.refresh()
            win.refresh()
            self.assertEqual(st.read().calib_step, "")
            self.assertIsNone(ov.top)
        finally:
            li.save_settings = saved
            root.destroy()
            tmp.cleanup()


# --------------------------------------------------------------------------- #
# Calibration
# --------------------------------------------------------------------------- #

class CalibrationTests(unittest.TestCase):
    FACE, CX, CY = 100.0, 320.0, 240.0          # face 100 px wide, resting nose position
    OPEN = ((0.28, 0.28), (0.03, 0.03))         # open eyes: EAR, blink scores

    def frame(self, dx=0.0, dy=0.0, eyes=None, smile=0.01, yaw=0.0, pitch=0.0):
        """Head moved dx/dy face widths in CURSOR directions (+x = right)."""
        ear, sc = eyes or self.OPEN
        nose = np.array([self.CX - dx * self.FACE, self.CY + dy * self.FACE])   # image x mirrored
        return li.CalibFrame(nose, self.FACE, (yaw, pitch), ear, sc, smile)

    def run_cal(self, script, seed=4):
        """script: (seconds, frame kwargs or a list of them per frame) -> the Calibration."""
        rng = np.random.default_rng(seed)
        cal, t = li.Calibration(0.0), 0.0
        for secs, kw in script:
            for _ in range(int(round(secs * FPS))):
                t += 1 / FPS
                f = self.frame(**kw)
                if f is not None:
                    f.nose = f.nose + rng.normal(0, 0.4, 2)          # the user's camera noise
                cal.update(f, t)
        return cal

    def head_script(self, x=0.3, y=0.12, down_eyes=((0.2, 0.2), (0.4, 0.4))):
        return [(2.5, {}),
                (2.0, dict(dx=-x, yaw=15)), (2.0, dict(dx=x, yaw=-15)),
                (2.0, dict(dy=-y, pitch=8)), (2.0, dict(dy=y, pitch=-8, eyes=down_eyes))]

    BLINK = [(0.6, {}), (0.4, dict(eyes=((0.06, 0.06), (0.9, 0.9))))] * 3 + [(0.6, {})]
    SMILE = [(1.5, dict(smile=0.8))]

    def test_full_calibration(self):
        cal = self.run_cal(self.head_script() + self.BLINK + self.SMILE)
        self.assertTrue(cal.finished, cal.step)
        res = cal.results()
        self.assertAlmostEqual(res["head_x"], 0.6, delta=0.03)
        self.assertAlmostEqual(res["head_y"], 0.24, delta=0.02)
        self.assertEqual(res["turn_deg"], 30)
        self.assertAlmostEqual(res["blink_close_ratio"], 0.06 / 0.28 + 0.4 * (1 - 0.06 / 0.28), delta=0.02)
        self.assertEqual(res["blink_score_delta"], 0.4)      # deep, clear blinks: harder to fake
        self.assertAlmostEqual(res["smile_min"], 0.6, delta=0.01)
        self.assertEqual(cal.skipped, [])
        # Every head direction taught the blink detector how open eyes look there.
        self.assertEqual({tuple(f.pose) for f in cal.learned},
                         {(0.0, 0.0), (15, 0.0), (-15, 0.0), (0.0, 8), (0.0, -8)})

    def test_glasses_blinks_fit_the_blink_score(self):
        """Eyelid points barely move behind glasses; the score rises only ~0.3."""
        weak = [(0.6, {}), (0.4, dict(eyes=((0.25, 0.25), (0.33, 0.33))))] * 3 + [(0.6, {})]
        res = self.run_cal(self.head_script() + weak + self.SMILE).results()
        self.assertNotIn("blink_close_ratio", res)               # eyelids: keep the default
        self.assertAlmostEqual(res["blink_score_delta"], 0.15, delta=0.01)

    def test_steps_not_done_are_skipped(self):
        script = [(2.5, {}), (2.0, dict(dx=-0.3)), (2.0, dict(dx=0.3)),
                  (21.0, {}),                                    # never looks up...
                  (2.0, dict(dy=0.12))] + self.BLINK + [(21.0, {})]   # ...nor smiles
        cal = self.run_cal(script)
        self.assertTrue(cal.finished, cal.step)
        res = cal.results()
        self.assertEqual(cal.skipped, ["up", "smile"])
        self.assertAlmostEqual(res["head_y"], 0.24, delta=0.02)  # twice the bottom
        self.assertNotIn("smile_min", res)

    def test_face_lost_waits(self):
        cal = li.Calibration(0.0)
        for i in range(90):
            cal.update(None, (i + 1) / FPS)
        self.assertEqual(cal.step, "centre")
        self.assertIn("Can't see your face", cal.text())

    def test_calibrated_pointer_and_settings(self):
        screen = fe.ScreenSize(1920, 1080)
        hp = li.HeadPointer(screen.width, screen.height)
        blink = li.BlinkDetector(None, 0.55, 0.70, 0.2, 1.5, 0.6)
        gestures = li.FaceGestures()
        default = [hp.gain(lvl, s) for lvl in (1, 3) for s in (0.1, 2.0)]
        # A saved calibration with the defaults' own range changes nothing...
        li.apply_calibration({"head_x": 0.8, "head_y": 0.8 * (1080 / 1920) / li.HEAD_Y_GAIN},
                             hp, blink, gestures)
        np.testing.assert_allclose([hp.gain(lvl, s) for lvl in (1, 3) for s in (0.1, 2.0)], default)
        # ...a user whose natural range is 0.5 x 0.2 face widths crosses the
        # screen with exactly that at speed 1, at a normal pace.
        li.apply_calibration({"head_x": 0.5, "head_y": 0.2, "blink_close_ratio": 0.6,
                              "blink_open_ratio": 0.75, "blink_score_delta": 0.15,
                              "smile_min": 0.5}, hp, blink, gestures)
        g = hp.gain(1, 2.0)
        self.assertAlmostEqual(abs(g[0]) * 0.5, 1920)
        self.assertAlmostEqual(g[1] * 0.2, 1080)
        self.assertGreater(abs(hp.gain(3, 2.0)[0]), abs(g[0]))   # higher speeds still go faster
        self.assertEqual((blink.close_ratio, blink.open_ratio, blink.score_delta), (0.6, 0.75, 0.15))
        self.assertEqual(gestures.threshold("smile"), 0.5)
        li.apply_calibration(None, hp, blink, gestures)              # back to the defaults
        self.assertIsNone(hp.calib)
        self.assertEqual(gestures.threshold("smile"), li.GESTURES["smile"][1])

    def test_summary(self):
        text = li.calibration_summary({"head_x": 0.5, "turn_deg": 28, "smile_min": 0.6}, ["blink"])
        self.assertIn("28 degrees", text)
        self.assertIn("Skipped: blink", text)


# --------------------------------------------------------------------------- #
# Smooth cursor output
# --------------------------------------------------------------------------- #

class CursorGlideTests(unittest.TestCase):
    def run_glide(self, positions, cam_fps=30.0, jitter_s=0.004, seed=1):
        """Camera positions at cam_fps (arriving a little late, at random) ->
        the cursor at li.OUTPUT_HZ: list of (time, x)."""
        rng = np.random.default_rng(seed)
        g, out = li.CursorGlide(), []
        frames = [(i / cam_fps, x, i / cam_fps + rng.uniform(0, jitter_s))
                  for i, x in enumerate(positions)]
        t, k, latest = 0.0, 0, None
        while t < len(positions) / cam_fps + 0.1:
            while k < len(frames) and frames[k][2] <= t:
                latest = frames[k]
                k += 1
            if latest is not None:
                g.target(latest[1], 500.0, latest[0], t)
                out.append((t, float(g.at(t)[0])))
            t += 1 / li.OUTPUT_HZ
        return out

    def test_a_head_turn_moves_the_cursor_evenly(self):
        speed = 2400.0                                       # px/s, a normal turn
        xs = [100.0] * 10 + [100 + speed * i / 30 for i in range(1, 31)] + [100 + speed] * 10
        out = self.run_glide(xs)
        steps = np.diff([x for _, x in out])
        moving = steps[np.abs(steps) > 0.01]
        per_tick = speed / li.OUTPUT_HZ                      # 20 px
        # Before: one 80 px jump per camera frame. Now ~20 px every 8 ms.
        self.assertLess(moving.max(), per_tick * 1.8)
        self.assertLess(np.percentile(moving, 90), per_tick * 1.3)
        self.assertAlmostEqual(out[-1][1], 100 + speed, places=3)   # arrives exactly

    def test_still_cursor_stays_still(self):
        out = self.run_glide([700.0] * 60)
        self.assertEqual({x for _, x in out}, {700.0})

    def test_lag_is_at_most_a_frame(self):
        xs = [100.0] * 5 + [900.0] * 10
        out = self.run_glide(xs, jitter_s=0.0)
        arrived = next(t for t, x in out if x == 900.0)
        self.assertLessEqual(arrived - 5 / 30, 0.05 + 1 / li.OUTPUT_HZ)

    def test_click_lands_on_the_target(self):
        g = li.CursorGlide()
        g.target(100, 100, 0.0, 0.0)
        g.target(400, 100, 1 / 30, 1 / 30)
        g.finish()
        self.assertEqual(list(g.at(1 / 30 + 0.001)), [400.0, 100.0])


# --------------------------------------------------------------------------- #
# Close gesture
# --------------------------------------------------------------------------- #

class CloseGestureTests(unittest.TestCase):
    def worker(self):
        w = li.VisionWorker.__new__(li.VisionWorker)
        w.args = types.SimpleNamespace(no_close_gesture=False, close_gesture_mar=0.6,
                                       close_gesture_hold=3.0)
        w.gesture_since = w.gesture_low_since = None
        w.gesture_announced = False
        w.state = types.SimpleNamespace(stop=threading.Event())
        return w

    def quits(self, seq, jaw=None) -> bool:
        """seq of (mouth aspect ratio, eyes open) at 30 FPS -> did EyeSync shut down?"""
        w, t = self.worker(), 0.0
        for mar, eyes_open in seq:
            t += 1 / FPS
            w._close_gesture(mar, eyes_open, t, jaw)
        return w.state.stop.is_set()

    def test_brief_wide_opening_does_not_even_beep(self):
        w, t, beeps = self.worker(), 0.0, []
        old, li.desktop.play_warning_sound = li.desktop.play_warning_sound, lambda: beeps.append(1)
        try:
            for mar in [0.7] * 12 + [0.05] * 30:       # 0.4 s wide open, e.g. a breath
                t += 1 / FPS
                w._close_gesture(mar, True, t)
        finally:
            li.desktop.play_warning_sound = old
        self.assertEqual(beeps, [])
        self.assertFalse(w.state.stop.is_set())

    def test_jaw_not_dropped_does_not_start(self):
        """The ratio reads wide open but MediaPipe sees the jaw closed (e.g. head turned)."""
        self.assertFalse(self.quits([(0.7, True)] * 120, jaw=0.15))
        self.assertTrue(self.quits([(0.7, True)] * 96, jaw=0.6))

    def test_head_pose_and_turned_mouth(self):
        def rot(yaw, pitch):
            a, b = np.radians(yaw), np.radians(pitch)
            ry = np.array([[np.cos(a), 0, np.sin(a)], [0, 1, 0], [-np.sin(a), 0, np.cos(a)]])
            rx = np.array([[1, 0, 0], [0, np.cos(b), -np.sin(b)], [0, np.sin(b), np.cos(b)]])
            m = np.eye(4)
            m[:3, :3] = ry @ rx
            return m
        for yaw, pitch in ((0, 0), (20, 0), (-15, 10), (25, -12)):
            got = fe.head_pose(rot(yaw, pitch))
            self.assertAlmostEqual(abs(got[0]), abs(yaw), delta=1.5)
            self.assertAlmostEqual(abs(got[1]), abs(pitch), delta=1.5)
        # An ordinary opening (0.45) seen with the head turned 30 degrees: the
        # mouth looks narrower, so the plain ratio reads ~0.52; the pose undoes it.
        lm = np.zeros((478, 2), np.float32)
        lm[fe.MOUTH_LEFT], lm[fe.MOUTH_RIGHT] = (0.45, 0.6), (0.45 + 0.1 * np.cos(np.radians(30)), 0.6)
        lm[fe.UPPER_LIP], lm[fe.LOWER_LIP] = (0.5, 0.6), (0.5, 0.6 + 0.045)
        self.assertGreater(fe.mouth_aspect_ratio(lm, 640, 640), 0.51)
        self.assertAlmostEqual(fe.mouth_aspect_ratio(lm, 640, 640, (30.0, 0.0)), 0.45, places=2)

    def test_talking_does_not_quit(self):
        self.assertFalse(self.quits([(0.45 * abs(np.sin(i / 3)), True) for i in range(600)]))

    def test_yawn_does_not_start(self):
        self.assertFalse(self.quits([(0.8, False)] * 150))       # eyes squeezed shut

    def test_short_open_cancels(self):
        self.assertFalse(self.quits([(0.7, True)] * 60 + [(0.05, True)] * 90))

    def test_held_open_quits(self):
        self.assertTrue(self.quits([(0.7, True)] * 96))

    def test_wavering_and_squinting_still_quits(self):
        # What a real held-open mouth looks like: dips below the start level,
        # brief deeper dips, eyes squinting after the start.
        seq = [(0.7, True)] * 10
        for i in range(90):
            mar = 0.5 if i % 15 < 9 else (0.35 if i % 15 < 12 else 0.65)
            seq.append((mar, i % 4 != 0))
        self.assertTrue(self.quits(seq))

    def test_half_second_sag_still_quits(self):
        # Seen in a real log: tiring after ~1-2 s and the opening sagging
        # for half a second cancelled the gesture six times in a row.
        seq = [(0.7, True)] * 40 + [(0.30, True)] * 15 + [(0.55, False)] * 50
        self.assertTrue(self.quits(seq))

    def test_closing_mouth_cancels(self):
        self.assertFalse(self.quits([(0.7, True)] * 45 + [(0.1, True)] * 15 + [(0.7, False)] * 60))


# --------------------------------------------------------------------------- #
# Cursor motion
# --------------------------------------------------------------------------- #

class CursorMotionTests(unittest.TestCase):
    def simulate(self, level: int, noise: float, seed: int = 3):
        """Head still 3 s, turns 800 px over 1 s, then still for 3.5 s."""
        rng = np.random.default_rng(seed)
        mc, beta, start, stop, vmax = li.SENSITIVITY_LEVELS[level]
        f, m = li.OneEuroFilter(mc, beta), li.CursorMotion(start, stop, vmax)
        pos = []
        for i in range(225):
            t = i / FPS
            u = min(max(t - 3.0, 0.0), 1.0)
            true_x = 400 + 800 * (3 * u * u - 2 * u * u * u)
            pos.append(m(f(np.array([true_x, 540.0]) + rng.normal(0, noise, 2), t), t).copy())
        return np.array(pos)

    def test_lands_and_stops(self):
        # Noise = jitter (px, std) of the head target; the head pointer's own
        # is ~4-10 px, 25 px is a very noisy webcam.
        for level in li.SENSITIVITY_LEVELS:
            for noise in (8, 25):
                for seed in (1, 2, 3):
                    with self.subTest(level=level, noise=noise, seed=seed):
                        pos = self.simulate(level, noise, seed)
                        speed = np.linalg.norm(np.diff(pos, axis=0), axis=1) * FPS
                        moving = np.flatnonzero(speed > 1)
                        stop_s = (moving[-1] + 1) / FPS - 4.0
                        self.assertLess(stop_s, 1.3, "cursor kept moving after the head stopped")
                        self.assertLess(abs(pos[-1][0] - 1200), 40, "cursor stopped off target")
                        self.assertLess(np.ptp(pos[-40:], axis=0).max(), 5, "cursor wobbles at rest")

    def test_cursor_keeps_up_and_higher_levels_need_less_turning(self):
        # A cursor that trails the head makes you keep turning, then overshoots:
        # at every level it must arrive with the head (the turn ends at 4.0 s).
        for level in sorted(li.SENSITIVITY_LEVELS):
            pos = self.simulate(level, 15)
            arrive = np.flatnonzero(np.abs(pos[:, 0] - 1200) < 50)[0] / FPS
            self.assertLess(arrive, 4.1, f"cursor trails the head at level {level}")
        ranges = [li.HEAD_RANGE[level] for level in sorted(li.HEAD_RANGE)]
        self.assertEqual(ranges, sorted(ranges, reverse=True))


# --------------------------------------------------------------------------- #
# Website protocol
# --------------------------------------------------------------------------- #

class WebsiteTests(unittest.TestCase):
    def test_origin_matching(self):
        allowed = li.DEFAULT_SITE_ORIGINS
        site = allowed[0]
        self.assertTrue(li.is_website_origin(site, allowed))
        self.assertTrue(li.is_website_origin(site.replace("https", "http") + ":443", allowed))
        self.assertFalse(li.is_website_origin("https://evil.example.com", allowed))
        self.assertFalse(li.is_website_origin("", allowed))
        self.assertFalse(li.is_website_origin("null", allowed))

    def test_websocket_payload_and_activation(self):
        from websockets.asyncio.client import connect

        screen = fe.ScreenSize(1920, 1080)
        state = li.SharedState(screen, 2, False)
        state.update(x=float("nan"), y=100.0, face=True, confidence=0.9)
        args = types.SimpleNamespace(dashboard_size="1920x1080", site_origin=li.DEFAULT_SITE_ORIGINS,
                                     always_active=False, ws_host="localhost", ws_ports=[8799],
                                     fps=30)

        async def scenario():
            server = asyncio.create_task(li.websocket_task(args, state, screen))
            try:
                for _ in range(50):                       # wait for the port to open
                    try:
                        ws = await connect("ws://localhost:8799/eye-tracker",
                                           origin=li.DEFAULT_SITE_ORIGINS[0])
                        break
                    except OSError:
                        await asyncio.sleep(0.1)
                else:
                    self.fail("WebSocket server did not start")
                msgs = [json.loads(await asyncio.wait_for(ws.recv(), 2)) for _ in range(15)]
                active = state.read().site_clients
                await ws.close()                          # page reload / another page
                await asyncio.sleep(0.2)
                reloading = state.read().site_clients
                await asyncio.sleep(li.RECONNECT_GRACE_S)  # ...but it never came back
                return msgs, active, reloading, state.read().site_clients
            finally:
                state.stop.set()
                await server

        saved, li.RECONNECT_GRACE_S = li.RECONNECT_GRACE_S, 0.5
        try:
            msgs, active, reloading, after = asyncio.run(scenario())
        finally:
            li.RECONNECT_GRACE_S = saved
        self.assertEqual(active, 1, "website connection did not activate EyeSync")
        self.assertEqual(reloading, 1, "control dropped while the website reconnects")
        self.assertEqual(after, 0, "disconnect not noticed")
        for m in msgs:
            self.assertEqual(set(m), {"x", "y", "blink", "confidence", "face"})
            self.assertTrue(all(np.isfinite([m["x"], m["y"]])), "NaN sent to the website")
        self.assertEqual(msgs[0]["x"], 960.0)             # NaN replaced by the centre

    def test_quitting_tells_the_dashboard_to_press_connect(self):
        from websockets.asyncio.client import connect
        from websockets.exceptions import ConnectionClosed

        screen = fe.ScreenSize(1920, 1080)
        state = li.SharedState(screen, 1, False)
        args = types.SimpleNamespace(dashboard_size="800x600", site_origin=li.DEFAULT_SITE_ORIGINS,
                                     always_active=False, ws_host="localhost", ws_ports=[8795],
                                     fps=30)

        async def scenario():
            server = asyncio.create_task(li.websocket_task(args, state, screen))
            for _ in range(50):
                try:
                    ws = await connect("ws://localhost:8795/", origin=li.DEFAULT_SITE_ORIGINS[0])
                    break
                except OSError:
                    await asyncio.sleep(0.1)
            await asyncio.wait_for(ws.recv(), 2)
            state.stop.set()                              # mouth wide open / Quit / F12
            try:
                while True:
                    await asyncio.wait_for(ws.recv(), 3)
            except ConnectionClosed as exc:
                code, reason = exc.rcvd.code, exc.rcvd.reason
            await server
            return code, reason

        code, reason = asyncio.run(scenario())
        self.assertEqual(code, 4000)
        self.assertIn("press Connect", reason)

    def test_dashboard_buttons_control_eyesync(self):
        """The dashboard's buttons (commands over the same WebSocket) and their status replies."""
        from websockets.asyncio.client import connect

        screen = fe.ScreenSize(1920, 1080)
        state = li.SharedState(screen, 1, False)
        actions = li.Actions(state)
        args = types.SimpleNamespace(dashboard_size="1920x1080", site_origin=li.DEFAULT_SITE_ORIGINS,
                                     always_active=False, ws_host="localhost", ws_ports=[8797],
                                     fps=30)

        async def command(ws, msg):
            await ws.send(json.dumps(msg))
            while True:                               # skip the 30/s data messages
                m = json.loads(await asyncio.wait_for(ws.recv(), 2))
                if "type" in m:
                    return m

        async def scenario():
            server = asyncio.create_task(li.websocket_task(args, state, screen, None, actions))
            out = {}
            try:
                for _ in range(50):
                    try:
                        ws = await connect("ws://localhost:8797/eye-tracker",
                                           origin=li.DEFAULT_SITE_ORIGINS[0])
                        break
                    except OSError:
                        await asyncio.sleep(0.1)
                else:
                    self.fail("WebSocket server did not start")
                plain = [json.loads(await asyncio.wait_for(ws.recv(), 2)) for _ in range(5)]
                out["no_status_unasked"] = all("type" not in m for m in plain)
                out["active_at_start"] = li.control_active(state.read(), args)
                r = await command(ws, {"action": "mouse", "value": False})
                out["disabled"] = (r["mouse_enabled"], r["active"], li.control_active(state.read(), args))
                r = await command(ws, {"action": "mouse", "value": True})
                out["enabled"] = (r["mouse_enabled"], r["active"])
                await command(ws, {"action": "recenter"})
                out["recenter"] = state.recenter_request.is_set()
                r = await command(ws, {"action": "calibrate"})
                out["calibrate"] = (r["calibrating"], state.calibrate_request.is_set())
                r = await command(ws, {"action": "calibrate", "value": "cancel"})
                out["calibrate_cancel"] = (r["calibrating"], state.calibrate_cancel.is_set())
                out["speed"] = (await command(ws, {"action": "speed", "value": 3}))["speed"]
                out["click"] = (await command(ws, {"action": "click_mode", "value": "dwell"}))["click_mode"]
                out["gestures"] = (await command(ws, {"action": "gestures", "value": False}))["gestures"]
                out["bad"] = (await command(ws, {"action": "speed", "value": 9}))["type"]
                out["junk"] = (await command(ws, "hello"))["type"]
                # the website's calibration progress needs no reply (not even an error)
                await ws.send(json.dumps({"type": "calibration", "event": "start", "points": 9}))
                out["after_calibration"] = (await command(ws, {"action": "status"}))["type"]
                await command(ws, {"action": "mouse", "value": False})
                await ws.close()
                await asyncio.sleep(0.3)
                out["reset_after_leaving"] = state.read().remote_off
                return out
            finally:
                state.stop.set()
                await server

        saved, li.save_settings = li.save_settings, lambda **kw: None   # leave real settings alone
        try:
            out = asyncio.run(scenario())
        finally:
            li.save_settings = saved
        self.assertTrue(out["no_status_unasked"], "an older dashboard would get status messages")
        self.assertTrue(out["active_at_start"])
        self.assertEqual(out["disabled"], (False, False, False))
        self.assertEqual(out["enabled"], (True, True))
        self.assertTrue(out["recenter"])
        self.assertEqual(out["calibrate"], (True, True))
        self.assertEqual(out["calibrate_cancel"], (False, True))
        self.assertEqual((out["speed"], out["click"], out["gestures"]), (3, "dwell", False))
        self.assertEqual((out["bad"], out["junk"]), ("error", "error"))
        self.assertEqual(out["after_calibration"], "status")
        self.assertFalse(out["reset_after_leaving"], "Disable must not outlive the dashboard")

    def test_website_controls_everything(self):
        """WEBSITE.md: probe, live status, pause, the camera view, quit."""
        from websockets.asyncio.client import connect
        from websockets.exceptions import ConnectionClosed

        screen = fe.ScreenSize(1920, 1080)
        state = li.SharedState(screen, 1, False)
        actions = li.Actions(state)
        actions.show_window = lambda: None                 # never touch the real window
        args = types.SimpleNamespace(dashboard_size="800x600", site_origin=li.DEFAULT_SITE_ORIGINS,
                                     always_active=False, ws_host="localhost", ws_ports=[8794],
                                     fps=30)
        site = li.DEFAULT_SITE_ORIGINS[0]

        async def until(ws, kind, ok=lambda m: True):
            while True:
                m = json.loads(await asyncio.wait_for(ws.recv(), 3))
                if m.get("type") == kind and ok(m):
                    return m

        async def scenario():
            server = asyncio.create_task(li.websocket_task(args, state, screen, None, actions))
            out = {}
            try:
                for _ in range(50):
                    try:
                        async with connect("ws://localhost:8794/?probe=1", origin=site) as ws:
                            first = json.loads(await asyncio.wait_for(ws.recv(), 2))
                            try:
                                await asyncio.wait_for(ws.recv(), 2)
                            except ConnectionClosed:
                                pass
                            out["probe"] = (first["type"], first["state"], first["version"],
                                            ws.close_code, state.read().site_clients)
                        break
                    except OSError:
                        await asyncio.sleep(0.1)
                ws = await connect("ws://localhost:8794/", origin=site)
                await ws.send(json.dumps({"action": "pause", "value": True}))
                out["paused"] = (await until(ws, "status"))["paused"]
                state.update(sensitivity=4)                # e.g. a hotkey: pushed to the page
                out["pushed"] = (await until(ws, "status", lambda m: m["speed"] == 4))["speed"]
                await ws.send(json.dumps({"action": "preview", "value": True}))
                state.set_preview(np.zeros((240, 320, 3), np.uint8))
                image = (await until(ws, "preview"))["image"]
                out["preview"] = (image.startswith("data:image/jpeg;base64,"),
                                  state.read().remote_preview)
                await ws.send(json.dumps({"action": "preview", "value": False}))
                await until(ws, "status")
                out["preview_off"] = state.read().remote_preview
                await ws.send(json.dumps({"action": "quit"}))
                try:
                    while True:
                        await asyncio.wait_for(ws.recv(), 3)
                except ConnectionClosed:
                    pass
                out["quit"] = (state.stop.is_set(), ws.close_code)
                return out
            finally:
                state.stop.set()
                await server

        saved, li.save_settings = li.save_settings, lambda **kw: None
        try:
            out = asyncio.run(scenario())
        finally:
            li.save_settings = saved
        self.assertEqual(out["probe"], ("eyesync", "running", li.VERSION, 4003, 0))
        self.assertTrue(out["paused"])
        self.assertEqual(out["pushed"], 4)
        self.assertEqual(out["preview"], (True, True))
        self.assertFalse(out["preview_off"])
        self.assertEqual(out["quit"], (True, 4000))

    def test_api_key_gate(self):
        """Only the website or the API key get in; a new key drops the old key's apps."""
        from websockets.asyncio.client import connect
        from websockets.exceptions import ConnectionClosed

        screen = fe.ScreenSize(1920, 1080)
        state = li.SharedState(screen, 2, False)
        args = types.SimpleNamespace(dashboard_size="1920x1080", site_origin=li.DEFAULT_SITE_ORIGINS,
                                     always_active=False, ws_host="localhost", ws_ports=[8798],
                                     fps=30)
        url = "ws://localhost:8798/eye-tracker"

        async def closed_with(ws):
            """Read until the server closes us -> (code, reason); None if it never does."""
            try:
                async with asyncio.timeout(2):
                    while True:
                        await ws.recv()
            except ConnectionClosed as exc:
                return exc.rcvd.code, exc.rcvd.reason
            except TimeoutError:
                return None

        async def scenario(api_key):
            server = asyncio.create_task(li.websocket_task(args, state, screen, api_key))
            out = {}
            try:
                for _ in range(50):                       # wait for the port to open
                    try:
                        app = await connect(f"{url}?key={api_key.get()}")
                        break
                    except OSError:
                        await asyncio.sleep(0.1)
                else:
                    self.fail("WebSocket server did not start")
                json.loads(await asyncio.wait_for(app.recv(), 2))
                out["app_active"] = state.read().site_clients
                site = await connect(url, origin=li.DEFAULT_SITE_ORIGINS[0])
                await asyncio.wait_for(site.recv(), 2)
                out["no_key"] = await closed_with(await connect(url))
                out["wrong_key"] = await closed_with(await connect(f"{url}?key=esk_not_the_key"))
                out["other_site"] = await closed_with(
                    await connect(url, origin="https://evil.example.com"))
                old = api_key.get()
                api_key.regenerate()
                out["app_after_new_key"] = await closed_with(app)
                out["old_key"] = await closed_with(await connect(f"{url}?key={old}"))
                await asyncio.wait_for(site.recv(), 2)    # the website is not affected
                fresh = await connect(f"{url}?key={api_key.get()}")
                await asyncio.wait_for(fresh.recv(), 2)
                out["active_at_end"] = state.read().site_clients
                await fresh.close()
                await site.close()
                return out
            finally:
                state.stop.set()
                await server

        with tempfile.TemporaryDirectory() as tmp:
            out = asyncio.run(scenario(li.ApiKey(Path(tmp) / "key.txt")))
        self.assertEqual(out["app_active"], 1, "a correct API key did not switch EyeSync on")
        self.assertEqual(out["no_key"], (4001, "API key required"))
        self.assertEqual(out["wrong_key"], (4001, "invalid API key"))
        self.assertEqual(out["other_site"], (4001, "API key required"))
        self.assertEqual(out["app_after_new_key"], (4001, "API key changed"))
        self.assertEqual(out["old_key"], (4001, "invalid API key"))
        self.assertEqual(out["active_at_end"], 2)     # the website + the app with the new key


class LowLightMesh:
    SWITCH = fe.LowLight.SWITCH_FRAMES


class LowLightTests(unittest.TestCase):
    """fe.LowLight with a stand-in face mesh that only 'sees' a face in a clean picture."""

    class Mesh:
        def __init__(self):
            self.calls = 0

        def process(self, img):
            self.calls += 1
            # noisy dark frames have big pixel-to-pixel jumps; the enhanced one is smooth
            ok = np.abs(np.diff(img[:, :, 0].astype(int), axis=1)).mean() < 8 and img.mean() > 20
            return np.zeros((478, 2)) if ok else None

    def frames(self, mean, noise, n=20):
        rng = np.random.default_rng(0)
        return [np.clip(rng.normal(mean, noise, (120, 160, 3)), 0, 255).astype(np.uint8)
                for _ in range(n)]

    def test_brief_face_loss_does_not_flip_modes(self):
        ll, mesh = fe.LowLight(), self.Mesh()
        for fr in self.frames(30, 25):                  # dark room: switches to enhanced
            ll.process(mesh, fr)
        self.assertTrue(ll.active)
        real = mesh.process
        for i, fr in enumerate(self.frames(30, 25, 40)):
            # every 4th frame the face is lost in the enhanced picture (a hand, a wide mouth)
            mesh.process = (lambda img: None) if i % 4 == 0 else real
            ll.process(mesh, fr)
            mesh.process = real
            self.assertTrue(ll.active, f"flipped to plain at frame {i}")

    def test_normal_light_never_enhances(self):
        ll, mesh = fe.LowLight(), self.Mesh()
        for fr in self.frames(130, 2):
            self.assertIsNotNone(ll.process(mesh, fr))
        self.assertFalse(ll.active)
        self.assertEqual(mesh.calls, 20)                # one face-mesh run per frame

    def test_dark_noisy_room_switches_to_enhanced_and_back(self):
        ll, mesh = fe.LowLight(), self.Mesh()
        found = [ll.process(mesh, fr) is not None for fr in self.frames(30, 25)]
        self.assertTrue(all(found), "face lost in the dark")
        self.assertTrue(ll.active)
        self.assertLess(mesh.calls, 20 + LowLightMesh.SWITCH + 1)   # then enhanced only: no double work
        for fr in self.frames(140, 2, 3):               # lights on
            self.assertIsNotNone(ll.process(mesh, fr))
        self.assertFalse(ll.active)


class StandbyTests(unittest.TestCase):
    """After a quit, EyeSync.pyw waits in site_access.wait_for_visit (timings scaled down)."""

    PORT = 8796

    def run_standby(self, visits, wake_at=None, key_path=None, after_quit=True):
        """visits: list of (seconds after start, origin, query). Returns (result, seconds)."""
        import socket
        import site_access

        t0 = time.monotonic()
        clock = time.monotonic
        woken = threading.Event()
        done = threading.Event()        # the standby returned: stop visiting (next test!)

        def visitor():
            for at, origin, query in visits:
                while clock() - t0 < at and not done.is_set():
                    time.sleep(0.01)
                if done.is_set():
                    return
                try:
                    with socket.create_connection(("127.0.0.1", self.PORT), timeout=1) as c:
                        c.sendall(f"GET /eye-tracker{query} HTTP/1.1\r\nHost: localhost\r\n"
                                  f"Origin: {origin}\r\nUpgrade: websocket\r\n\r\n".encode())
                        c.recv(100)
                except OSError:
                    pass
            if wake_at is not None:
                while clock() - t0 < wake_at and not done.is_set():
                    time.sleep(0.01)
                woken.set()

        thread = threading.Thread(target=visitor, daemon=True)
        thread.start()
        with tempfile.TemporaryDirectory() as tmp:
            kp = Path(tmp) / "key.txt"
            if key_path:
                kp.write_text(key_path, encoding="utf-8")
            got = site_access.wait_for_visit(ports=(self.PORT,), key_path=kp, quiet_s=0.6,
                                             confirm_s=0.5, wake=woken.is_set,
                                             after_quit=after_quit)
        secs = clock() - t0
        done.set()
        thread.join(2)
        return got, secs

    SITE = li.DEFAULT_SITE_ORIGINS[0]

    def test_website_opened_starts_eyesync(self):
        got, secs = self.run_standby([(1.0, self.SITE, ""), (1.3, self.SITE, "")], wake_at=3)
        self.assertEqual(got, "website")
        self.assertLess(secs, 2)

    def test_dashboard_already_open_at_login_starts_eyesync(self):
        # At login (not after a quit) a dashboard the browser reopened counts at once.
        tries = [(0.1 + 0.3 * i, self.SITE, "") for i in range(8)]
        self.assertEqual(self.run_standby(tries, wake_at=2.8, after_quit=False)[0], "website")

    # The website's automatic retries after a lost connection: gaps of ~1, 2, 4 s
    # (+-20%, so at least 0.8, 1.6, 3.2 s). Its Connect button: a try, and ~0.5 s later another.
    RETRIES = [(0.1, "", ""), (0.9, "", ""), (2.5, "", "")]

    def tries(self, schedule):
        return [(at, self.SITE, query) for at, _, query in schedule]

    def test_website_retrying_after_quit_does_not_restart(self):
        # Quit with the mouth (or Quit / F12) while the website is connected: it keeps
        # retrying by itself - EyeSync must stay closed.
        self.assertEqual(self.run_standby(self.tries(self.RETRIES), wake_at=3.0)[0], "shortcut")

    def test_connect_click_after_quit_restarts(self):
        click = [(3.0, "", ""), (3.5, "", "")]
        got, secs = self.run_standby(self.tries(self.RETRIES + click), wake_at=5.0)
        self.assertEqual(got, "website")
        self.assertLess(secs, 4.0)

    def test_background_tab_does_not(self):
        # Browsers slow a hidden tab's retries to one a minute: single tries never start it.
        self.assertEqual(self.run_standby([(1.0, self.SITE, ""), (2.0, self.SITE, "")],
                                          wake_at=2.8)[0], "shortcut")

    def test_only_the_website_or_the_key(self):
        evil = [(1.0, "https://evil.example.com", ""), (1.3, "https://evil.example.com", "")]
        self.assertEqual(self.run_standby(evil, wake_at=2)[0], "shortcut")
        key = "esk_" + "k" * 32
        wrong = [(1.0, "", "?key=esk_wrong"), (1.3, "", "?key=esk_wrong")]
        self.assertEqual(self.run_standby(wrong, wake_at=2, key_path=key)[0], "shortcut")
        right = [(1.0, "", f"?key={key}"), (1.3, "", f"?key={key}")]
        self.assertEqual(self.run_standby(right, wake_at=3, key_path=key)[0], "website")

    def ws_visit(self, query, origin=None, delay=0.3):
        """A real browser-like WebSocket visit: (first message, close code)."""
        from websockets.exceptions import ConnectionClosed
        from websockets.sync.client import connect
        time.sleep(delay)
        with connect(f"ws://127.0.0.1:{self.PORT}/{query}", origin=origin or self.SITE,
                     open_timeout=2) as ws:
            first = json.loads(ws.recv(timeout=2))
            try:
                ws.recv(timeout=2)
            except ConnectionClosed:
                pass
            return first, ws.close_code

    def standby_with(self, query, after_quit=True, wake_after=1.5):
        import site_access
        out, woken = {}, threading.Event()

        def visit():
            try:
                out["visit"] = self.ws_visit(query)
            finally:
                time.sleep(wake_after)
                woken.set()
        th = threading.Thread(target=visit, daemon=True)
        th.start()
        with tempfile.TemporaryDirectory() as tmp:
            out["got"] = site_access.wait_for_visit(ports=(self.PORT,), key_path=Path(tmp) / "k",
                                                    wake=woken.is_set, after_quit=after_quit)
        th.join(5)
        return out

    def test_website_probe_learns_eyesync_is_installed(self):
        out = self.standby_with("?probe=1")
        first, code = out["visit"]
        self.assertEqual((first["type"], first["state"], first["version"], first["closed_by_user"]),
                         ("eyesync", "standby", li.VERSION, True))
        self.assertEqual(code, 4003)
        self.assertEqual(out["got"], "shortcut")              # a probe never starts EyeSync

    def test_connect_with_start_starts_eyesync_at_once(self):
        out = self.standby_with("?start=1")                   # even after a quit
        self.assertEqual(out["visit"][0]["state"], "starting")
        self.assertEqual(out["visit"][1], 4002)
        self.assertEqual(out["got"], "website")

    def test_other_sites_cannot_probe(self):
        import site_access
        from websockets.exceptions import InvalidStatus
        out, woken = {}, threading.Event()

        def visit():
            time.sleep(0.3)
            try:
                self.ws_visit("?probe=1", origin="https://evil.example.com", delay=0)
            except InvalidStatus as exc:
                out["status"] = exc.response.status_code
            woken.set()
        threading.Thread(target=visit, daemon=True).start()
        with tempfile.TemporaryDirectory() as tmp:
            got = site_access.wait_for_visit(ports=(self.PORT,), key_path=Path(tmp) / "k",
                                             wake=woken.is_set)
        self.assertEqual((got, out.get("status")), ("shortcut", 503))

    def test_launcher_knows_why_eyesync_closed(self):
        """Quit -> only Connect restarts; dashboard closed -> it may; a crash -> restart."""
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourceFileLoader("eyesync_launcher", str(PROJECT / "EyeSync.pyw"))
        spec = importlib.util.spec_from_loader("eyesync_launcher", loader)
        launcher = importlib.util.module_from_spec(spec)
        loader.exec_module(launcher)
        import subprocess
        launcher.time = types.SimpleNamespace(monotonic=time.monotonic, sleep=lambda s: None)
        for codes, after_quit in (([li.EXIT_QUIT], True), ([li.EXIT_DASHBOARD_CLOSED], False),
                                  ([li.EXIT_CRASHED, 0xC0000005, li.EXIT_QUIT], True)):
            calls = iter(codes)
            launcher.subprocess = types.SimpleNamespace(
                call=lambda *a, **k: next(calls), CREATE_NO_WINDOW=subprocess.CREATE_NO_WINDOW)
            self.assertEqual(launcher.run_until_quit(Path("python"), []), after_quit, codes)
            self.assertIsNone(next(calls, None), "every crash is restarted")

    def test_port_is_free_for_eyesync_afterwards(self):
        import site_access
        self.run_standby([], wake_at=0.3)
        socks = site_access._listen(self.PORT)
        self.assertTrue(socks, "standby did not release the port")
        for s in socks:
            s.close()


class ApiKeyTests(unittest.TestCase):
    def test_made_once_kept_and_replaced(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "key.txt"
            a = li.ApiKey(path)
            key = a.get()
            self.assertTrue(key.startswith("esk_") and len(key) >= 36)
            self.assertEqual(li.ApiKey(path).get(), key)            # same key after a restart
            self.assertNotEqual(li.ApiKey(Path(tmp) / "b.txt").get(), key)   # random per install
            self.assertTrue(a.matches(key))
            for wrong in (key[:-1], key + "x", "", "é" * 36):
                self.assertFalse(a.matches(wrong), wrong)
            a.regenerate()
            self.assertNotEqual(a.get(), key)
            self.assertEqual(a.version, 1)
            self.assertFalse(a.matches(key))
            self.assertEqual(li.ApiKey(path).get(), a.get())        # the new key is saved

    def test_damaged_file_gets_a_new_key(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "key.txt"
            path.write_text("short", encoding="utf-8")
            key = li.ApiKey(path).get()
            self.assertTrue(key.startswith("esk_"))
            self.assertEqual(path.read_text(encoding="utf-8").strip(), key)


if __name__ == "__main__":
    unittest.main()
